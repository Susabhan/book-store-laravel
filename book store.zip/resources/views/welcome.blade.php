@extends('layouts.app')

@section('title','susabhan')

@section('content')
    <div class="flex-center position-ref full-height">
        <div class="content">
            <div class="title m-b-md">
            Wellcome to our ACME book store
            </div>
        </div>
    </div>
@endsection

