<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body id="app-layout">
    <?php echo $__env->make('common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if(Session::has('message')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
    
    <?php if(Session::has('warning')): ?>
        <div class="alert alert-warning"><?php echo e(Session::get('warning')); ?></div>
    <?php endif; ?>
    
    <?php if(Session::has('danger')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('danger')); ?></div>
    <?php endif; ?>
    
    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
