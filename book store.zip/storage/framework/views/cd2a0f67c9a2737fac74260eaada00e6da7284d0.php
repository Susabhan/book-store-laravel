<div class="form-group">
    <?php echo Form::label('title', 'Title'); ?>

	<?php echo Form::text('title', '', ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('description', 'Description'); ?>

	<?php echo Form::text('description', '', ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('image', 'Book Image'); ?>

	<?php echo Form::file('image', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('src_file', 'File (.pdf)'); ?>

    <?php echo Form::file('src_file', null, ['class' => 'form-control']); ?>

</div>

<button class="btn btn-success" type="submit">Add book</button>
