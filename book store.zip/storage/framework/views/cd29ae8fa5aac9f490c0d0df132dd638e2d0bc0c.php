<?php echo Form::model($book->review, ['action' => 'BookReviewController@store']); ?>

<?php echo Form::hidden('book_id', $book->id); ?>

<div class="form-group">
    <?php echo Form::label('rating', 'Rating (1-5)'); ?>

    <?php echo Form::text('rating', '', ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('comment', 'Comment'); ?>

    <?php echo Form::text('comment', '', ['class' => 'form-control']); ?>

</div>
<?php echo Form::submit('Add review', ['class' => 'btn btn-primary']); ?>

<?php echo Form::close(); ?>