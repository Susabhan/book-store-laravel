<?php $__env->startSection('title',$book->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-body">
        <h3 class="title"> <?php echo e($book->title); ?></h3>
        <table class="table table-striped task-table">
            <thead>
            <th colspan="2">&nbsp;</th>
            </thead>
            <tbody>
            <tr>
                <td class="table-text">
                    <div><strong>ID</strong></div>
                </td>
                <td class="table-text">
                    <div id="bookId"><?php echo e($book->id); ?></div>
                </td>
            </tr>
            <td class="table-text">
                <div><strong>Image</strong></div>
            </td>
            <td class="table-text">
                <div>
                    <img src="<?php echo e(Storage::disk('local')->url($book->image)); ?>"
                         style="max-width:200px; max-height:200px"/>
                </div>
            </td>
            </tr>
            <tr>
                <td class="table-text">
                    <div><strong>Title</strong></div>
                </td>
                <td class="table-text">
                    <div><?php echo e($book->title); ?></div>
                </td>
            </tr>
            <tr>
                <td class="table-text">
                    <div><strong>Description</strong></div>
                </td>
                <td class="table-text">
                    <div><?php echo e($book->description); ?></div>
                </td>
            </tr>
            <tr>
                <td class="table-text">
                    <div><strong>Average Rating</strong></div>
                </td>
                <td class="table-text">
                    <div><?php echo e($book->getAverageRating()); ?></div>
                </td>
            </tr>
            <tr>
                <td class="table-text">
                    <div><strong>Downloads</strong></div>
                </td>
                <td class="table-text">
                    <div id="book-downloads"><?php echo e($book->number_of_downloads); ?></div>
                </td>
            </tr>
            <tr>
                <td class="table-text">
                    <div><strong>Created</strong></div>
                </td>
                <td class="table-text">
                    <div><?php echo e(date('F d, Y H:i', strtotime($book->date_created))); ?></div>
                </td>
            </tr>
            <tr>
                <td class="table-text">
                    <div><strong>Reviews</strong></div>
                </td>
                <td class="table-text">
                    <?php $__currentLoopData = $book->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>Rating: <?php echo e($review->rating); ?> Comment: <?php echo e($review->comment); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <a href="<?php echo e(url('books/'.$book->id.'/read')); ?>" class="btn btn-success" id="read-book-btn">Read</a>
                    <a href="<?php echo e(url('books/'.$book->id.'/download')); ?>" class="btn btn-success" id="download-book-btn">Download</a>
                    <button class="btn btn-success" data-toggle="modal" data-target="#myModal">Add Review</button>
                </td>
            </tr>
            </tbody>
        </table>
        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Add Review</h4>
                    </div>
                    <div class="modal-body">
                        <?php echo $__env->make('bookreview.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>