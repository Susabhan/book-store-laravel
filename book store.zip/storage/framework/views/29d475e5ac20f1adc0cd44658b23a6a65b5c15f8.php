<?php $__env->startSection('title','Books'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <table class="table table-striped task-table">
                <thead>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Average Rating</th>
                <th>Date Created</th>
                <th>Actions</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="table-text">
                            <div><?php echo e($book->id); ?></div>
                        </td>
                        <td class="table-text">
                            <div><a href="<?php echo e(url('books/'.$book->id)); ?>"><?php echo e($book->title); ?></a></div>
                        </td>
                        <td class="table-text">
                            <div><?php echo e($book->description); ?></div>
                        </td>
                        <td class="table-text">
                            <div><?php echo e($book->getAverageRating()); ?></div>
                        </td>
                        <td>
                            <div><?php echo e(date('F d, Y H:i', strtotime($book->date_created))); ?></div>
                        </td>
                        <td>
                            <a href="<?php echo e(url('books/'.$book->id)); ?>" class="btn btn-default"><i
                                        class="fa fa-btn fa-book"></i>View</a>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>