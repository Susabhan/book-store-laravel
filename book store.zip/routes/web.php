<?php


Route::get('/', function () {
    return view('welcome');
});

Route::get('books/{book}/read', 'BookController@read');
Route::get('books/{book}/download', 'BookController@download');
Route::get('books/{book}/updateDownloads', 'BookController@updateDownloads');
Route::resource('books','BookController',[
	'except' => ['delete','edit']
]);

Route::resource('reviews','BookReviewController',[
	'except' => ['delete','edit']
]);
